matricula = input ('Digite seu número de matrícula: ')
idLivro = input ('Digite o id do livro ou livros que deseja, separando por vírgulas: ')
print ('Agradecemos o seu pedido, aguarde a confirmação do processo de emprestimo e se aceito comparecer em nosso estabelecimento com prazo máximo de 5 dias úteis!.')

